
var smsApi={
URL:'http://caltonmobile.com/calton/api.php?sender=EDAD',
USERNAME:'augbazi@gmail.com',
PASSWORD:'PRINCE?;=2020'

};

module.exports = smsApi;